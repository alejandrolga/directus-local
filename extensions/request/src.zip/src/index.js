// src/extensions/panel/index.js
import PanelComponent from "./panel.vue";
//import { sql } from '@codemirror/lang-sql';

export default {
	id: "custom-sql-panel",
	name: "KPI's Monitoring",
	icon: "content_paste_search", // Puedes elegir cualquier icono que quieras
	component: PanelComponent,
	options: [
		{
			field: "query_sql",
			name: "SQL Request",
			type: "string",
			meta: {
				interface: "input-code",
				options: {
					language: "sql",
				},
			},
		},
	],
};
/*
	options: [
		{
			field: 'start_date',
			name: 'Start Date',
			type: 'dateTime',
			meta: {
				interface: 'textArea',
				width: 'half',
			},
		},
	{
			field: 'end_date',
			name: 'End Date',
			type: 'dateTime',
			meta: {
				interface: 'textArea',
				width: 'half',
			},
		},
	{
			field: 'query_sql',
			name: 'Query',
			type: 'string',
			meta: {
				interface: 'input-multiline',
				width: 'full',
			},
		},
	],
};
*/
