<template>
	<div class="directus-container">
	  <table>
		<thead>
		  <tr>
			<th v-for="header in tableHeaders" :key="header.value" :style="{ width: columnWidths[header.value] + 'px' }">
			  {{ header.text }}
			  <span class="resize-handle" @mousedown="startResizing(header.value)"></span>
			</th>
		  </tr>
		</thead>
		<tbody>
		  <tr v-for="item in filteredResults" :key="item.id" @click="handleRowClick(item)">
			<td v-for="header in tableHeaders" :key="header.value">{{ item[header.value] }}</td>
		  </tr>
		</tbody>
	  </table>
	  <div v-if="infoMessage">{{ infoMessage }}</div>
	</div>
  </template>
  
  <script>
  export default {
	props: {
	  query_sql: {
		type: String,
		default: "",
	  },
	},
  
	data() {
	  return {
		query: this.query_sql,
		result: [],
		searchQuery: "",
		infoMessage: "",
		tableHeaders: [],
		loading: false,
		tableSort: null,
		columnWidths: {},
		resizingColumn: null,
		startX: 0,
		startWidth: 0,
	  };
	},
	watch: {
	  query_sql: {
		immediate: true,
		handler(newQuery) {
		  this.query = newQuery;
		  this.executeQuery();
		},
	  },
	  searchQuery(newQuery) {
		// Guarda el contenido de la barra de búsqueda en localStorage
		localStorage.setItem('searchQuery', newQuery || "");
	  },
	},
	computed: {
	  filteredResults() {
		if (!this.searchQuery) {
		  return this.result;
		}
		const searchTerm = this.searchQuery.toLowerCase();
		return this.result.filter(item => {
		  return Object.values(item).some(value =>
			String(value).toLowerCase().includes(searchTerm)
		  );
		});
	  },
	},
	methods: {
	  async executeQuery() {
		this.infoMessage = "";
		this.loading = true;
		try {
		  const response = await fetch("/my-extension/post", {
			method: "POST",
			headers: {
			  "Content-Type": "application/json",
			},
			body: JSON.stringify({ variable: this.query }),
		  });
		  if (!response.ok) {
			throw new Error("Invalid SQL request");
		  }
  
		  const data = await response.json();
		  this.result = Array.isArray(data) ? data : [];
		  if (this.result.length === 0) {
			this.infoMessage = "No results found.";
		  } else {
			this.tableHeaders = this.getHeaders(this.result);
			this.initializeColumnWidths();
		  }
		} catch (error) {
		  console.error("Error executing query:", error);
		  this.infoMessage = "Error executing query.";
		  this.result = [];
		} finally {
		  this.loading = false;
		}
	  },
	  getHeaders(data) {
		if (data.length === 0) return [];
		const keys = Object.keys(data[0]);
		return keys.map((key) => ({
		  text: key,
		  value: key,
		  sortable: true,
		  resizable: true,
		  width: "250",
		}));
	  },
	  initializeColumnWidths() {
		this.columnWidths = this.tableHeaders.reduce((widths, header) => {
		  widths[header.value] = 250; // ancho inicial
		  return widths;
		}, {});
	  },
	  startResizing(column) {
		this.resizingColumn = column;
		this.startX = event.pageX;
		this.startWidth = this.columnWidths[column];
		document.addEventListener('mousemove', this.resizeColumn);
		document.addEventListener('mouseup', this.stopResizing);
	  },
	  resizeColumn(event) {
		if (!this.resizingColumn) return;
		const offset = event.pageX - this.startX;
		this.columnWidths[this.resizingColumn] = this.startWidth + offset;
	  },
	  stopResizing() {
		document.removeEventListener('mousemove', this.resizeColumn);
		document.removeEventListener('mouseup', this.stopResizing);
		this.resizingColumn = null;
	  },
	  onSortChange(by, desc) {
		this.result.sort((a, b) => {
		  const aValue = a[by];
		  const bValue = b[by];
		  if (aValue < bValue) return desc ? 1 : -1;
		  if (aValue > bValue) return desc ? -1 : 1;
		  return 0;
		});
	  },
	  handleRowClick(item) {
		this.$router.push(`/content/motion_graphic/${item.id}`);
	  },
	  clearSearch() {
		this.searchQuery = "";
	  },
	},
	mounted() {
	  this.executeQuery();
	},
  };
  </script>
  
  <style scoped>
  .directus-container {
	max-width: 100%;
	max-height: 100%;
	overflow-x: auto;
	overflow-y: auto;
  }
  
  table {
	width: 100%;
	border-collapse: collapse;
  }
  
  th, td {
	border: 1px solid #ddd;
	padding: 8px;
  }
  
  th {
	position: relative;
  }
  
  .resize-handle {
	position: absolute;
	right: 0;
	top: 0;
	bottom: 0;
	width: 5px;
	cursor: col-resize;
  }
  </style>
  